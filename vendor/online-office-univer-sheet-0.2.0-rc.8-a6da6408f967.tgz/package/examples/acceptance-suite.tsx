import React, {useRef, useState} from 'react'
import {createRoot} from 'react-dom/client'
import {SpreadsheetEditor, type SpreadsheetEditorHandle, type WorkbookSnapshot} from '@online-office/univer-sheet'
import {createInlineAcceptance} from './inline-acceptance'
import '@online-office/univer-sheet/style.css'

/** Public-package consumer. Every case uses a separate test document/storage key. */
export async function mountAcceptanceSuite(element: HTMLElement) {
  const params=new URLSearchParams(location.search),scenario=params.get('case')??params.get('acceptance')??'index'
  const room=params.get('room')??'suite-isolated-0913'
  if(scenario==='features'){
    const {mountFeaturesAcceptance}=await import('./features-acceptance')
    await mountFeaturesAcceptance(element);return
  }
  if(scenario==='inline') {
    const Inline=await createInlineAcceptance(room)
    createRoot(element).render(<Inline/>);return
  }
  if(scenario==='office') {
    const {mountOfficeAcceptance}=await import('./office-acceptance')
    await mountOfficeAcceptance(element);return
  }
  function Index(){return <main style={{maxWidth:900,margin:'48px auto',font:'15px/1.8 system-ui',padding:24}}>
    <h1>Excel 交互验收</h1><p>这是实际包的验收入口，不是“全部功能已交付”声明。以下页面使用隔离测试数据，不会打开或覆盖默认 demo 文档。</p>
    <h2><a href={`?acceptance=features&case=features&room=${encodeURIComponent(room+'-features-v3')}`}>合并 / 冻结 / 筛选 / 记录排序 / 条件格式 / 下拉列表 · 双页</a></h2>
    <p>新增 schema 3 隔离示例；点击原生工具栏实际操作，同一链接打开两页验证同步。评论随记录排序移动。排序暂限纯值记录，不能与合并区域重叠。</p>
    <h2><a href={`?acceptance=sheets&case=sheets&room=${encodeURIComponent(room)}`}>工作表与底部菜单 · 单机</a></h2>
    <p>右键重命名、复制、删除；原生拖拽顺序；末尾 + 创建；撤销、重载和只读。工作表集合协同仍未支持，不能将此页面的操作当作两页同步能力。</p>
    <h2><a href={`?acceptance=inline&case=inline&room=${encodeURIComponent(room)}`}>原生混排与共享冻结 · 双页</a></h2>
    <p>同一链接打开两页。在单元格按 F2 输入 @，使用宿主候选插入身份节点，选择部分文字调整样式，Shift+Enter 换行。用顶部计数器检查本地提交及远端无回声。</p>
    <h2><a href={`?acceptance=office&case=office&large=1&room=${encodeURIComponent(room+'-large')}`}>10 万单元格 · 性能与宿主集成</a></h2>
    <p>读取就绪耗时、滚动帧和浏览器可用的内存指标；演示宿主评论动作、在线选区与纯 XLSX 导出。此页保留 schema 1，用于大表固定单元格协同测试，不启用共享冻结和结构操作。</p>
    <p>仍未交付：工作表/行列增删移动协同、公式引用随排序改写，以及图片/附件等任意原子内联呈现和完整输入法、剪贴板验收。新增六项功能仅在显式创建的 schema 3 文档开放，不会自动升级或清空现有文档。</p>
  </main>}
  function Sheets(){
    const ref=useRef<SpreadsheetEditorHandle>(null),[readonly,setReadonly]=useState(false),[narrow,setNarrow]=useState(false),[result,setResult]=useState(''),[error,setError]=useState('')
    const key=`exlsx:sheets-acceptance:${room}`
    const [snapshot]=useState<WorkbookSnapshot>(()=>{
      const stored=localStorage.getItem(key);if(stored)return JSON.parse(stored)
      return {id:room,name:'底部工作表验收',styles:{},sheetOrder:['data','guide'],sheets:{
        data:{id:'data',name:'数据',rowCount:220,columnCount:26,cellData:{0:{0:{v:'右键底部标签测试重命名、复制、删除'},1:{f:'=1+2',v:3}}},columnData:{0:{w:360}}},
        guide:{id:'guide',name:'说明',rowCount:220,columnCount:26,cellData:{0:{0:{v:'拖拽调整顺序，末尾 + 创建新表。此页为单机验收，不声称结构协同。'}}},columnData:{0:{w:560}}}
      }} as unknown as WorkbookSnapshot
    })
    function inspect(){const s=ref.current!.getSnapshot();setResult(JSON.stringify({order:s.sheetOrder,sheets:s.sheetOrder.map(id=>({id,name:s.sheets[id].name,rows:s.sheets[id].rowCount,columns:s.sheets[id].columnCount,A1:s.sheets[id].cellData?.[0]?.[0]}))}))}
    return <main style={{height:'100vh',display:'flex',flexDirection:'column',font:'13px system-ui'}}>
      <header style={{padding:'8px 12px',background:'#edf5f0',borderBottom:'1px solid #cbdad0'}}>
        <strong>底部工作表验收 · 单机操作（不代表结构协同支持）</strong>
        <div style={{display:'flex',gap:8,marginTop:8}}><a href="?acceptance=index">验收目录</a><button onClick={()=>setReadonly(v=>!v)}>{readonly?'恢复编辑':'只读'}</button><button onClick={()=>setNarrow(v=>!v)}>切换窄屏</button><button onClick={inspect}>读取工作表模型</button><button onClick={()=>{localStorage.setItem(key,JSON.stringify(ref.current!.getSnapshot()));setResult('测试快照已保存，刷新恢复')}}>保存测试快照</button></div>
        <output aria-label="工作表模型" style={{display:'block',overflowWrap:'anywhere',maxHeight:90,overflow:'auto'}}>{result}</output><output role="alert">{error}</output>
      </header>
      <div style={{flex:1,minHeight:0,width:narrow?420:'100%',maxWidth:'100%'}}><SpreadsheetEditor ref={ref} workbookId={room} initialSnapshot={snapshot} readOnly={readonly} showHeader={false} showSaveState={false} autoSave={false} onError={e=>setError(e.message)}/></div>
    </main>
  }
  createRoot(element).render(scenario==='sheets'?<Sheets/>:<Index/>)
}
