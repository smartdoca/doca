import React,{useRef,useState} from 'react'
import {createRoot} from 'react-dom/client'
import {SpreadsheetEditor,type SpreadsheetEditorHandle,type SpreadsheetCommentMarker,type WorkbookSnapshot} from '@online-office/univer-sheet'
import {createExlsxBaseline,restoreExlsxDocument,createExlsxCollaborationSession,encodeStateAsUpdate,type ExlsxRecoveryBundle} from '@online-office/univer-sheet/yjs'
import '@online-office/univer-sheet/style.css'

/** Host-only transport and comments. This isolated fixture is not a production ACK queue. */
export async function mountFeaturesAcceptance(element:HTMLElement){
  const params=new URLSearchParams(location.search),room=params.get('room')??'features-schema3-isolated',key=`exlsx-features:${room}`
  const stored=localStorage.getItem(key)
  const values=[['记录','分数','状态','负责人'],['丙',30,'待办','张三'],['甲',10,'进行中','李四'],['乙',20,'完成','王五'],['丁',40,'待办','赵六']]
  const snapshot={id:room,name:'共享功能验收',styles:{},sheetOrder:['records'],sheets:{records:{id:'records',name:'记录',rowCount:220,columnCount:26,cellData:Object.fromEntries(values.map((row,r)=>[r,Object.fromEntries(row.map((v,c)=>[c,{v}]))])),columnData:{0:{w:160},1:{w:120},2:{w:160},3:{w:140}}}}} as unknown as WorkbookSnapshot
  const recovery:ExlsxRecoveryBundle=stored?{...JSON.parse(stored),update:new Uint8Array(JSON.parse(stored).update)}:await createExlsxBaseline(snapshot,`${room}-epoch`,{schemaVersion:3})
  if(!stored)localStorage.setItem(key,JSON.stringify({...recovery,update:[...recovery.update]}))
  const doc=await restoreExlsxDocument(recovery),sessionId=crypto.randomUUID(),session=await createExlsxCollaborationSession({doc,baseline:recovery.baseline,sessionId})
  const channel=new BroadcastChannel(key)
  let writes=0,received=0,notify=()=>{},setMarkers:(m:SpreadsheetCommentMarker[])=>void=()=>{}
  session.onLocalTransaction(event=>{writes++;channel.postMessage({type:'update',event});notify()})
  channel.onmessage=async({data})=>{
    if(data.type==='join')channel.postMessage({type:'update',event:{codec:recovery.baseline.codec,schemaVersion:recovery.baseline.schemaVersion,epochId:recovery.baseline.epochId,update:encodeStateAsUpdate(doc)}})
    if(data.type==='update'){try{await session.applyUpdate(data.event);received++;notify()}catch(e){showError(String(e))}}
    if(data.type==='comments'){localStorage.setItem(key+':comments',JSON.stringify(data.markers));setMarkers(data.markers)}
  }
  channel.postMessage({type:'join'})
  let showError:(s:string)=>void=()=>{}
  function Fixture(){
    const ref=useRef<SpreadsheetEditorHandle>(null),[,rerender]=useState(0),[readonly,setReadonly]=useState(false),[result,setResult]=useState(''),[error,setError]=useState(''),[narrow,setNarrow]=useState(false)
    const [markers,updateMarkers]=useState<SpreadsheetCommentMarker[]>(()=>JSON.parse(localStorage.getItem(key+':comments')??'[]'))
    notify=()=>rerender(n=>n+1);setMarkers=updateMarkers;showError=setError
    const comment=()=>{const anchor=ref.current?.captureCommentAnchor();if(!anchor)return;const next=[...markers,{id:crypto.randomUUID(),anchor,color:'#d99a00'}];updateMarkers(next);localStorage.setItem(key+':comments',JSON.stringify(next));channel.postMessage({type:'comments',markers:next})}
    return <main style={{height:'100vh',display:'flex',flexDirection:'column',font:'13px system-ui'}}>
      <header style={{padding:10,background:'#edf5f0'}}><a href="?acceptance=index">验收目录</a> · <strong>共享功能 · schema 3 · 隔离文档</strong> · <output aria-label="协同计数">本地提交 {writes} · 远端接收 {received}</output>
        <div style={{display:'flex',gap:8,margin:'6px 0'}}><button onClick={()=>setReadonly(v=>!v)}>{readonly?'恢复编辑':'只读'}</button><button onClick={()=>setNarrow(v=>!v)}>切换窄屏</button><button onClick={()=>{const s=ref.current!.getSnapshot();setResult(JSON.stringify({rows:s.sheets.records.cellData,merges:s.sheets.records.mergeData,freeze:s.sheets.records.freeze,resources:s.resources,anchors:markers.map(m=>({id:m.id,ranges:ref.current!.resolveCommentAnchorRanges(m.anchor)}))}))}}>读取功能模型</button><button onClick={()=>{const c=session.checkpoint(writes);localStorage.setItem(key,JSON.stringify({...c,update:[...c.update]}));setResult('checkpoint 已保存')}}>保存测试 checkpoint</button></div>
        <p style={{margin:0}}>选择 A1:D5：首行为标题，按选区首列排序整条记录。评论跟随记录。合并不删除原文；筛选、条件格式、下拉列表使用原生面板。公式文档及合并重叠范围暂不能排序。</p>
        <output aria-label="功能模型" style={{display:'block',maxHeight:70,overflow:'auto',overflowWrap:'anywhere'}}>{result}</output><output role="alert">{error}</output>
      </header>
      <div style={{flex:1,minHeight:0,width:narrow?420:'100%',maxWidth:'100%'}}><SpreadsheetEditor ref={ref} workbookId={room} collaboration={session} readOnly={readonly} toolbarLayout="two-row" showHeader={false} showSaveState={false} currentSessionId={sessionId} commentMarkers={markers} onError={e=>setError(e.message)} menus={[{id:'comment',title:'评论记录',ariaLabel:'评论记录',path:'ribbon.others.others',tone:'amber',icon:<span>▤</span>,requiresEditPermission:false,enabled:c=>!!c.selection,action:comment}]}/></div>
    </main>
  }
  createRoot(element).render(<Fixture/> )
}
