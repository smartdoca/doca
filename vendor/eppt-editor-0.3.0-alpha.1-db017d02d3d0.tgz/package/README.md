# @eppt/editor

面向 Doca 的 React 演示文稿编辑器，提供页面、文本、形状、图片、表格、图表、分节、放映、PPTX 交换和 Yjs 协同。

## 使用

```tsx
import { PresentationWorkspace } from '@eppt/editor'
import '@eppt/editor/styles.css'

export function Presentation() {
  return <PresentationWorkspace mode="edit" />
}
```

宿主注入资源、保存状态、presence、权限、导入导出和业务评论。包不依赖 Doca 域名、Cookie、路由或数据库。

## 当前协同协议

当前模型固定使用 `schemaVersion: 2`、`protocolVersion: 1`、`codec: "eppt"` 和 `codecRevision: 5`。包只接受这一组合，不提供 schema 或 codec 转换器。

文档恢复必须使用完整 Yjs checkpoint，不能用投影 JSON 替代。只有匹配队首消息 ID 与 epoch 的持久 ACK 才能移除 outbox 项；sync response 不等于 ACK。宿主拥有连接、认证、持久 outbox、checkpoint 和 epoch 切换。

## 资源与权限

图片模型只保存稳定资产 ID。宿主通过 `resources.uploadImage(file, { signal })` 和 `resources.resolveUrl(id)` 提供上传与短期显示地址。`mode="readonly"` 是权限入口；服务端仍必须校验写权限。

评论正文、成员、ACL、通知和历史属于宿主。编辑器只提供 `captureAnchor` / `resolveAnchor` 的稳定锚点能力。

## PPTX

导入 `.pptx` 会创建独立文稿，不覆盖活动协作谱系。支持的文本、形状、图片、表格和图表保持可编辑；复杂母版、动画或效果可能简化，并通过导入报告明确提示。`.ppt`、`.pptm` 和 JSON 文件不接受。

## 开发

```bash
yarn typecheck
yarn test
yarn build
```
