// Run through CUA against examples/acceptance-suite.tsx, case=sheets, fresh room.
// UI actions only; the demo's public read-only model output supplies assertions.
export async function verifySheetTabs(tab) {
  const assert=(ok,message)=>{if(!ok)throw new Error(message)}
  const button=name=>tab.playwright.getByRole('button',{name,exact:true})
  const sheet=name=>tab.playwright.getByRole('tab',{name,exact:true})
  const menu=()=>tab.playwright.getByRole('menu',{name:'工作表操作',exact:true})
  const read=async()=>{await button('读取工作表模型').click();return JSON.parse(await tab.playwright.getByLabel('工作表模型',{exact:true}).innerText())}
  const context=async name=>{await sheet(name).click({button:'right'});await menu().waitFor({state:'visible'})}
  await tab.playwright.locator('.uos-editor__overlay').waitFor({state:'hidden'})
  await context('数据')
  assert(JSON.stringify(await menu().getByRole('menuitem').allTextContents())===JSON.stringify(['重命名','复制','删除']),'exactly three menu actions')
  await menu().getByRole('menuitem',{name:'重命名',exact:true}).click()
  const rename=tab.playwright.getByRole('textbox',{name:'重命名 数据',exact:true})
  await rename.fill('项目数据');await rename.press('Enter')
  await context('项目数据');await menu().getByRole('menuitem',{name:'复制',exact:true}).click()
  let state=await read();const copy=state.sheets.find(s=>s.id!=='data'&&s.id!=='guide')
  assert(copy&&copy.name.includes('项目数据')&&copy.A1.v===state.sheets.find(s=>s.id==='data').A1.v,'new identity, preserved content')
  const rects=await tab.playwright.getByRole('tablist',{name:'Sheet tabs'}).getByRole('tab').evaluateAll(es=>es.map(e=>{const r=e.getBoundingClientRect();return {name:e.textContent,x:r.x,y:r.y,w:r.width,h:r.height}}))
  const from=rects.find(r=>r.name==='说明'),to=rects.find(r=>r.name==='项目数据')
  await tab.drag([from.x+from.w/2,from.y+from.h/2],[to.x+3,to.y+to.h/2]);state=await read()
  assert(state.order[0]==='guide','single drag reorders the real model')
  await button('撤销').click();assert((await read()).order[0]==='data','drag undo')
  await button('重做').click();assert((await read()).order[0]==='guide','drag redo')
  // Package-owned pinned footer selector, never required in host code.
  const add=tab.playwright.locator('.uos-editor div:has(+ div > [data-u-comp="slide-tab-bar"][aria-label="Sheet tabs"]) > button[data-u-comp="sheet-bar-append-button"]')
  await add.click();state=await read();const created=state.sheets.find(s=>!['data','guide',copy.id].includes(s.id))
  assert(created.rows===200&&created.columns===26,'bounded new sheet')
  await context(created.name);await menu().getByRole('menuitem',{name:'删除',exact:true}).click()
  await tab.playwright.getByRole('dialog',{name:'工作表操作',exact:true}).getByRole('button',{name:'删除',exact:true}).click()
  assert(!(await read()).order.includes(created.id),'delete')
  await button('撤销').click();assert((await read()).order.includes(created.id),'delete undo retains ID')
  await button('重做').click();assert(!(await read()).order.includes(created.id),'delete redo')
  await button('保存测试快照').click();await tab.reload()
  await tab.playwright.locator('.uos-editor__overlay').waitFor({state:'hidden'})
  await sheet(copy.name).waitFor({state:'visible'});state=await read()
  assert(state.order[0]==='guide'&&state.order.includes(copy.id),'snapshot reload keeps order and IDs')
  await button('只读').click();await context('项目数据')
  for(const item of await menu().getByRole('menuitem').all())assert(!(await item.isEnabled()),'readonly menu disabled')
  await tab.pressKey('Escape');assert(!(await add.isEnabled()),'readonly creation disabled')
  await button('切换窄屏').click();await context('项目数据')
  assert(await menu().isVisible(),'narrow context menu visible')
  return {sheets:state.sheets,readonly:true,narrow:true}
}
